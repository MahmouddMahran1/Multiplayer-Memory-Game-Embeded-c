#ifndef I2C_H
#define I2C_H

/* ============================================================
   i2c.h  —  Bare-metal TWI (I2C) master driver
   ============================================================ */

#include <stdint.h>

void    i2c_init(void);
uint8_t i2c_start(uint8_t addr_rw);   /* addr_rw = (addr<<1)|R/W */
void    i2c_stop(void);
uint8_t i2c_write(uint8_t data);
uint8_t i2c_read_ack(void);
uint8_t i2c_read_nack(void);

/* Convenience: write N bytes to a 7-bit address */
uint8_t i2c_write_bytes(uint8_t addr7, const uint8_t *buf, uint8_t len);

#endif /* I2C_H */
