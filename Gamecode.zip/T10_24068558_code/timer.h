#ifndef TIMER_H
#define TIMER_H

/* ============================================================
   timer.h  —  millis() and delay_ms() using Timer0
   Replaces Arduino's millis()/delay() with direct register
   access on ATmega328P.
   ============================================================ */

#include <stdint.h>

/* Call once in main() before enabling interrupts */
void timer0_init(void);

/* Returns milliseconds elapsed since timer0_init() */
uint32_t millis(void);

/* Blocking delay (uses millis internally — no WDT) */
void delay_ms(uint32_t ms);

#endif /* TIMER_H */
