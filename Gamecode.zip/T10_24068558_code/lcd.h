#ifndef LCD_H
#define LCD_H

/* ============================================================
   lcd.h  —  HD44780 16x2 LCD via PCF8574 I2C backpack
   ============================================================
   PCF8574 bit layout (standard wiring):
     P7 P6 P5 P4  P3  P2  P1 P0
     D7 D6 D5 D4  BL  EN  RW RS
   ============================================================ */

#include <stdint.h>
#include "config.h"

void lcd_init(void);
void lcd_backlight(uint8_t on);
void lcd_clear(void);
void lcd_set_cursor(uint8_t col, uint8_t row);
void lcd_print_str(const char *s);
void lcd_print_int(int16_t n);
void lcd_print_char(char c);

#endif /* LCD_H */
