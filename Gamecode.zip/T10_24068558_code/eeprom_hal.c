/* ============================================================
   eeprom_hal.c  —  Direct EEPROM access via ATmega328P regs
   ============================================================ */

#include <avr/io.h>
#include <avr/interrupt.h>
#include "eeprom_hal.h"

/* Wait for any previous write to complete */
static void eeprom_wait(void)
{
    while (EECR & (1u << EEPE)) { /* spin */ }
}

void eeprom_write_byte(uint16_t addr, uint8_t val)
{
    eeprom_wait();
    uint8_t sreg = SREG;
    cli();
    EEAR = addr;
    EEDR = val;
    EECR |= (1u << EEMPE);   /* Master write enable */
    EECR |= (1u << EEPE);    /* Write enable */
    SREG  = sreg;
}

uint8_t eeprom_read_byte(uint16_t addr)
{
    eeprom_wait();
    EEAR = addr;
    EECR |= (1u << EERE);    /* Read enable — result in EEDR immediately */
    return EEDR;
}

void eeprom_write_int16(uint16_t addr, int16_t val)
{
    eeprom_write_byte(addr,     (uint8_t)(val & 0xFFu));
    eeprom_write_byte(addr + 1u,(uint8_t)((uint16_t)val >> 8u));
}

int16_t eeprom_read_int16(uint16_t addr)
{
    uint8_t lo = eeprom_read_byte(addr);
    uint8_t hi = eeprom_read_byte(addr + 1u);
    return (int16_t)((uint16_t)hi << 8u | lo);
}

void eeprom_update_byte(uint16_t addr, uint8_t val)
{
    if (eeprom_read_byte(addr) != val) eeprom_write_byte(addr, val);
}

void eeprom_update_int16(uint16_t addr, int16_t val)
{
    if (eeprom_read_int16(addr) != val) eeprom_write_int16(addr, val);
}
