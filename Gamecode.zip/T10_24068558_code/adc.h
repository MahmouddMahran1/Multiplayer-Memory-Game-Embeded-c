#ifndef ADC_H
#define ADC_H

/* ============================================================
   adc.h  —  Single-shot ADC read for RNG seeding
   ============================================================ */

#include <stdint.h>

void     adc_init(void);
uint16_t adc_read(uint8_t channel);   /* channel 0-7 */

#endif /* ADC_H */
