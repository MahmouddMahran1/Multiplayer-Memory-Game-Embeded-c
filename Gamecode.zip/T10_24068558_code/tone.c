/* ============================================================
   tone.c  —  Passive buzzer via Timer1 CTC on OC1B (PB2)
   ============================================================
   Timer1 is a 16-bit timer.
   CTC mode, TOP = ICR1.
   OC1B toggles on compare match → square wave on PB2.

   f_out = F_CPU / (2 * prescaler * (ICR1 + 1))

   We choose prescaler = 8  →  ICR1 = F_CPU/(16 * f) - 1
   That gives:
     f = 150 Hz → ICR1 = 8332
     f = 300 Hz → ICR1 = 4166
     f = 700 Hz → ICR1 = 1785
     f =1000 Hz → ICR1 = 1249
     f =1047 Hz → ICR1 = 1193
   All fit in 16 bits comfortably.
   ============================================================ */

#include <avr/io.h>
#include "tone.h"
#include "timer.h"
#include "config.h"

void tone_init(void)
{
    /* PB2 (OC1B) as output */
    DDRB |= (1u << DDB2);
}

void tone_play(uint16_t freq_hz, uint16_t duration_ms)
{
    if (freq_hz == 0u) { tone_stop(); return; }

    /* ICR1 = F_CPU / (2 * 8 * freq) - 1 */
    uint32_t top = (F_CPU / ((uint32_t)16u * freq_hz));
    if (top > 0u) top--;
    if (top > 0xFFFFu) top = 0xFFFFu;

    /* Stop timer before reconfiguring */
    TCCR1B = 0;
    TCCR1A = 0;
    TCNT1  = 0;

    ICR1   = (uint16_t)top;
    OCR1B  = (uint16_t)(top >> 1u);   /* 50% duty — not needed for toggle but tidy */

    /*
     * Mode 14: Fast PWM, TOP = ICR1  (WGM13=1, WGM12=1, WGM11=1, WGM10=0)
     * COM1B1=0, COM1B0=1 → Toggle OC1B on compare match
     * Prescaler = 8 (CS11=1)
     */
    TCCR1A = (1u << COM1B0) | (1u << WGM11);
    TCCR1B = (1u << WGM13) | (1u << WGM12) | (1u << CS11);

    delay_ms(duration_ms);

    tone_stop();
}

void tone_stop(void)
{
    TCCR1B = 0;
    TCCR1A = 0;
    /* Drive pin LOW so buzzer is silent */
    PORTB &= ~(1u << PB2);
}
