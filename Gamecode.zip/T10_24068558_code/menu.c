/* ============================================================
   menu.c  —  Start menu + mode launcher
   ============================================================ */

#include "menu.h"
#include "game.h"
#include "display.h"
#include "audio.h"
#include "input.h"
#include "storage.h"
#include "timer.h"

void menu_update(void)
{
    if (!menuDrawn) {
        display_menu((int8_t)g.menuCursor);
        menuDrawn = TRUE;
    }

    int8_t btn = p1_pressed();

    if (btn == 1) {
        g.menuCursor = (MenuOption)((g.menuCursor + MENU_COUNT - 1u) % MENU_COUNT);
        audio_select();
        menuDrawn = FALSE;
    } else if (btn == 2) {
        g.menuCursor = (MenuOption)((g.menuCursor + 1u) % MENU_COUNT);
        audio_select();
        menuDrawn = FALSE;
    } else if (btn == 3) {
        audio_select();
        menuDrawn = FALSE;
        start_mode(g.menuCursor);
    }

    /* Secret wipe combo: hold all 8 buttons for 1 second */
    static uint32_t combo_start = 0u;

    if (p1_all_held() && p2_all_held()) {
        if (combo_start == 0u) combo_start = millis();
        if ((uint32_t)(millis() - combo_start) > 1000u) {
            storage_wipe();
            display_full(" Scores wiped! ", "  Hold to conf");
            audio_game_over();
            delay_ms(1500u);
            combo_start = 0u;
            menuDrawn   = FALSE;
        }
    } else {
        combo_start = 0u;
    }
}

void start_mode(MenuOption mode)
{
    g.p1.score    = 0;  g.p1.inputLen = 0;  g.p1.inputDone = FALSE;
    g.p2.score    = 0;  g.p2.inputLen = 0;  g.p2.inputDone = FALSE;
    g.activeSeq.length = 0;
    g.roundInProgress  = FALSE;
    g.awaitingInput    = FALSE;
    g.lastActivityMs   = millis();

    switch (mode) {
        case MENU_SOLO:
            g.state = STATE_SOLO_SPRINT;
            display_full("  Solo Sprint ", " Get ready... ");
            delay_ms(1000u);
            break;

        case MENU_DUEL:
            g.state = STATE_SYNC_DUEL;
            display_full(" Sync Duel! ", " Get ready... ");
            delay_ms(1000u);
            break;

        case MENU_CHALLENGER:
            g.state      = STATE_CHALLENGER;
            g.challPhase = CHALL_INPUT_A;
            display_full(" Challenger! ", "P1: set secret");
            delay_ms(1200u);
            break;

        default: break;
    }
}
