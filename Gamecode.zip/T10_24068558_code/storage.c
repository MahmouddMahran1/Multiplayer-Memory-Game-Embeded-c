/* ============================================================
   storage.c  —  EEPROM high-score persistence
   ============================================================ */

#include "storage.h"
#include "eeprom_hal.h"
#include "game.h"
#include "config.h"

void storage_init(void)
{
    uint8_t magic = eeprom_read_byte(EEPROM_MAGIC_ADDR);

    if (magic != EEPROM_MAGIC_VAL) {
        /* First boot — initialise EEPROM */
        eeprom_write_int16(EEPROM_ADDR_P1_HIGH, 0);
        eeprom_write_int16(EEPROM_ADDR_P2_HIGH, 0);
        eeprom_write_byte(EEPROM_MAGIC_ADDR, EEPROM_MAGIC_VAL);
        g.p1.highScore = 0;
        g.p2.highScore = 0;
    } else {
        g.p1.highScore = eeprom_read_int16(EEPROM_ADDR_P1_HIGH);
        g.p2.highScore = eeprom_read_int16(EEPROM_ADDR_P2_HIGH);
    }
}

void storage_update_high(void)
{
    if (g.p1.score > g.p1.highScore) {
        g.p1.highScore = g.p1.score;
        eeprom_update_int16(EEPROM_ADDR_P1_HIGH, g.p1.highScore);
    }
    if (g.p2.score > g.p2.highScore) {
        g.p2.highScore = g.p2.score;
        eeprom_update_int16(EEPROM_ADDR_P2_HIGH, g.p2.highScore);
    }
}

void storage_wipe(void)
{
    g.p1.highScore = 0;
    g.p2.highScore = 0;
    eeprom_write_int16(EEPROM_ADDR_P1_HIGH, 0);
    eeprom_write_int16(EEPROM_ADDR_P2_HIGH, 0);
}
