#ifndef EEPROM_HAL_H
#define EEPROM_HAL_H

/* ============================================================
   eeprom_hal.h  —  Direct EEPROM read/write (ATmega328P)
   Replaces the Arduino EEPROM library.
   ============================================================ */

#include <stdint.h>

void    eeprom_write_byte(uint16_t addr, uint8_t val);
uint8_t eeprom_read_byte(uint16_t addr);
void    eeprom_write_int16(uint16_t addr, int16_t val);
int16_t eeprom_read_int16(uint16_t addr);

/* Write-only-if-changed (reduces wear) */
void    eeprom_update_byte(uint16_t addr, uint8_t val);
void    eeprom_update_int16(uint16_t addr, int16_t val);

#endif /* EEPROM_HAL_H */
