/* ============================================================
   timer.c  —  millis() and delay_ms() via Timer0 CTC
   ============================================================
   Timer0 is configured in CTC mode with a prescaler of 64.
   At F_CPU = 16 MHz:
     tick period = 64 / 16 000 000 = 4 µs
     OCR0A = 249  →  (249+1) * 4 µs = 1 000 µs = 1 ms
   The ISR increments a 32-bit counter every millisecond.
   ============================================================ */

#include <avr/io.h>
#include <avr/interrupt.h>
#include "timer.h"

static volatile uint32_t _ms = 0;

/* Timer0 Compare-Match-A ISR fires every 1 ms */
ISR(TIMER0_COMPA_vect)
{
    _ms++;
}

void timer0_init(void)
{
    /* CTC mode (WGM01=1, WGM00=0) */
    TCCR0A = (1u << WGM01);

    /* Prescaler = 64  (CS01=1, CS00=1) */
    TCCR0B = (1u << CS01) | (1u << CS00);

    /* TOP = 249 → 1 ms period at 16 MHz / 64 */
    OCR0A = 249u;

    /* Enable Output-Compare-A interrupt */
    TIMSK0 = (1u << OCIE0A);
}

uint32_t millis(void)
{
    uint32_t val;
    /* Disable interrupts briefly to read the 4-byte value atomically */
    uint8_t sreg = SREG;
    cli();
    val = _ms;
    SREG = sreg;
    return val;
}

void delay_ms(uint32_t ms)
{
    uint32_t start = millis();
    while ((uint32_t)(millis() - start) < ms) { /* spin */ }
}
