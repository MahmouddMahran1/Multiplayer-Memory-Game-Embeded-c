#ifndef SCORE_H
#define SCORE_H

void score_update(void);
void enter_sleep(void);
void sleep_update(void);

#endif /* SCORE_H */
