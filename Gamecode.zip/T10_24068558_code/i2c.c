/* ============================================================
   i2c.c  —  Hardware TWI master (ATmega328P)
   ============================================================
   SCL frequency = F_CPU / (16 + 2 * TWBR * prescaler)
   For 100 kHz at 16 MHz:
     TWBR = (16000000/100000 - 16) / 2 = 72
   ============================================================ */

#include <avr/io.h>
#include "i2c.h"
#include "config.h"

#define TWI_STATUS   (TWSR & 0xF8u)

/* Status codes (master transmitter) */
#define TW_START          0x08u
#define TW_REP_START      0x10u
#define TW_MT_SLA_ACK     0x18u
#define TW_MT_DATA_ACK    0x28u
#define TW_MR_SLA_ACK     0x40u
#define TW_MR_DATA_ACK    0x50u
#define TW_MR_DATA_NACK   0x58u

static void twi_wait(void)
{
    while (!(TWCR & (1u << TWINT))) { /* spin */ }
}

void i2c_init(void)
{
    TWSR = 0;                   /* Prescaler = 1 */
    TWBR = 72u;                 /* 100 kHz @ 16 MHz */
    TWCR = (1u << TWEN);        /* Enable TWI */
}

uint8_t i2c_start(uint8_t addr_rw)
{
    /* Generate START */
    TWCR = (1u << TWINT) | (1u << TWSTA) | (1u << TWEN);
    twi_wait();
    if (TWI_STATUS != TW_START && TWI_STATUS != TW_REP_START) return 1u;

    /* Send SLA+R/W */
    TWDR = addr_rw;
    TWCR = (1u << TWINT) | (1u << TWEN);
    twi_wait();
    if (TWI_STATUS != TW_MT_SLA_ACK && TWI_STATUS != TW_MR_SLA_ACK) return 1u;

    return 0u;
}

void i2c_stop(void)
{
    TWCR = (1u << TWINT) | (1u << TWSTO) | (1u << TWEN);
}

uint8_t i2c_write(uint8_t data)
{
    TWDR = data;
    TWCR = (1u << TWINT) | (1u << TWEN);
    twi_wait();
    return (TWI_STATUS == TW_MT_DATA_ACK) ? 0u : 1u;
}

uint8_t i2c_read_ack(void)
{
    TWCR = (1u << TWINT) | (1u << TWEN) | (1u << TWEA);
    twi_wait();
    return TWDR;
}

uint8_t i2c_read_nack(void)
{
    TWCR = (1u << TWINT) | (1u << TWEN);
    twi_wait();
    return TWDR;
}

uint8_t i2c_write_bytes(uint8_t addr7, const uint8_t *buf, uint8_t len)
{
    if (i2c_start((uint8_t)((addr7 << 1u) | 0u))) return 1u;
    for (uint8_t i = 0u; i < len; i++) {
        if (i2c_write(buf[i])) { i2c_stop(); return 1u; }
    }
    i2c_stop();
    return 0u;
}
