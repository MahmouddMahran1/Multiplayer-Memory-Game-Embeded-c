#ifndef GAME_H
#define GAME_H

/* ============================================================
   game.h  —  Shared types, enums, and the global GameState
   Pure C99 — no C++ types (no bool from stdbool.h used
   below to stay C89-compatible; we define our own uint8_t flags)
   ============================================================ */

#include <stdint.h>
#include "config.h"

/* ── Boolean substitute ──────────────────────────────────── */
typedef uint8_t bool_t;
#define TRUE  1u
#define FALSE 0u

/* ── Top-level FSM states ────────────────────────────────── */
typedef enum {
    STATE_MENU = 0,
    STATE_SOLO_SPRINT,
    STATE_SYNC_DUEL,
    STATE_CHALLENGER,
    STATE_SCORE_DISPLAY,
    STATE_SLEEP
} SystemState;

/* ── Challenger sub-states ───────────────────────────────── */
typedef enum {
    CHALL_INPUT_A = 0,   /* P1 entering secret sequence    */
    CHALL_REPLICATE_B,   /* P2 replicating the sequence    */
    CHALL_PROOF_A,       /* P1 proving their sequence      */
    CHALL_RESULT         /* Show who scored                 */
} ChallengerPhase;

/* ── Menu options ────────────────────────────────────────── */
typedef enum {
    MENU_SOLO = 0,
    MENU_DUEL,
    MENU_CHALLENGER,
    MENU_COUNT           /* Sentinel — always last          */
} MenuOption;

/* ── Per-player runtime data ─────────────────────────────── */
typedef struct {
    int16_t  score;
    int16_t  highScore;
    bool_t   inputDone;
    int16_t  inputSeq[MAX_SEQ_LEN];
    int16_t  inputLen;
} PlayerData;

/* ── Active sequence ─────────────────────────────────────── */
typedef struct {
    int16_t  data[MAX_SEQ_LEN];
    int16_t  length;
} Sequence;

/* ── Central game state (one global instance) ────────────── */
typedef struct {
    SystemState      state;
    MenuOption       menuCursor;

    PlayerData       p1;
    PlayerData       p2;

    Sequence         activeSeq;
    int8_t           playerTurn;      /* 1 or 2                */
    ChallengerPhase  challPhase;

    uint32_t         lastActivityMs;  /* For sleep timeout     */
    uint32_t         turnStartMs;     /* For per-button timeout*/
    bool_t           awaitingInput;
    bool_t           roundInProgress;
    int16_t          compareIndex;
} GameState;

/* ── Single global instance ──────────────────────────────── */
extern GameState g;
extern bool_t    menuDrawn;

/* ── Pin index arrays (0-based) ──────────────────────────── */
/*   Defined in main.c                                        */
extern const uint8_t LED_BITS[NUM_LEDS];
extern const uint8_t P1_BITS[NUM_LEDS];
extern const uint8_t P2_BITS[NUM_LEDS];

#endif /* GAME_H */
