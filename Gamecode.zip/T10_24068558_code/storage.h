#ifndef STORAGE_H
#define STORAGE_H

/* ============================================================
   storage.h  —  EEPROM high-score persistence
   ============================================================ */

void storage_init(void);
void storage_update_high(void);
void storage_wipe(void);

#endif /* STORAGE_H */
