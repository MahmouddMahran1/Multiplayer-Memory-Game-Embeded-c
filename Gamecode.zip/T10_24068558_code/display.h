#ifndef DISPLAY_H
#define DISPLAY_H

/* ============================================================
   display.h  —  LCD + LED visual feedback helpers
   ============================================================ */

#include <stdint.h>

void display_splash(void);
void display_menu(int8_t cursor);
void display_scores(void);
void display_msg(const char *line0);
void display_full(const char *line0, const char *line1);
void display_win(void);
void display_sleep(void);
void display_wake(void);
void display_final_score(void);

void flash_sequence(const int16_t seq[], int16_t len, uint16_t on_ms);
void led_on(int8_t num);
void led_off(int8_t num);
void leds_off(void);

#endif /* DISPLAY_H */
