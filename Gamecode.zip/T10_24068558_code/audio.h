#ifndef AUDIO_H
#define AUDIO_H

/* ============================================================
   audio.h  —  Passive buzzer feedback tones
   ============================================================ */

void audio_correct(void);
void audio_wrong(void);
void audio_game_over(void);
void audio_select(void);
void audio_win(void);

#endif /* AUDIO_H */
