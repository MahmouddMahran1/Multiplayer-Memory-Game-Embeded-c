/* ============================================================
   audio.c  —  Passive buzzer tones via tone.h
   ============================================================ */

#include "audio.h"
#include "tone.h"
#include "timer.h"
#include "config.h"

void audio_correct(void)
{
    tone_play(TONE_CORRECT, TONE_DURATION_MS);
}

void audio_wrong(void)
{
    tone_play(TONE_WRONG, TONE_DURATION_MS * 2u);
}

void audio_game_over(void)
{
    /* Descending three-note jingle */
    tone_play(TONE_GAMEOVER + 100u, 200u);  delay_ms(20u);
    tone_play(TONE_GAMEOVER,        200u);  delay_ms(20u);
    tone_play(TONE_GAMEOVER - 50u,  400u);  delay_ms(20u);
    tone_stop();
}

void audio_select(void)
{
    tone_play(TONE_SELECT, 80u);
}

void audio_win(void)
{
    /* C5 E5 G5 C6 — major arpeggio */
    static const uint16_t notes[] = { 523u, 659u, 784u, 1047u };
    for (uint8_t i = 0u; i < 4u; i++) {
        tone_play(notes[i], 150u);
        delay_ms(20u);
    }
    tone_stop();
}
