/* ============================================================
   adc.c  —  ADC driver (single-shot, polling)
   ============================================================ */

#include <avr/io.h>
#include "adc.h"

void adc_init(void)
{
    /* AVCC reference, right-adjust result */
    ADMUX  = (1u << REFS0);
    /* Enable ADC, prescaler = 128 (125 kHz @ 16 MHz) */
    ADCSRA = (1u << ADEN) | (1u << ADPS2) | (1u << ADPS1) | (1u << ADPS0);
}

uint16_t adc_read(uint8_t channel)
{
    ADMUX  = (ADMUX & 0xF0u) | (channel & 0x07u);
    ADCSRA |= (1u << ADSC);                        /* Start conversion */
    while (ADCSRA & (1u << ADSC)) { /* wait */ }   /* Poll complete flag */
    return ADC;                                     /* 10-bit result     */
}
