/* ============================================================
   score.c  —  Score display + sleep state handlers
   ============================================================ */

#include "score.h"
#include "game.h"
#include "display.h"
#include "audio.h"
#include "input.h"
#include "timer.h"
#include "config.h"

static bool_t score_shown = FALSE;

void score_update(void)
{
    if (!score_shown) {
        display_final_score();
        score_shown = TRUE;
    }

    if (any_pressed()) {
        audio_select();
        score_shown = FALSE;
        /* reset_game_state() is defined in main.c — call via extern */
        extern void reset_game_state(void);
        reset_game_state();
        display_menu((int8_t)g.menuCursor);
    }
}

void enter_sleep(void)
{
    g.state = STATE_SLEEP;
    display_sleep();
}

void sleep_update(void)
{
    if (any_pressed()) {
        g.lastActivityMs = millis();
        g.state          = STATE_MENU;
        menuDrawn        = FALSE;
        display_wake();
        delay_ms(800u);
        display_menu((int8_t)g.menuCursor);
    }
}
