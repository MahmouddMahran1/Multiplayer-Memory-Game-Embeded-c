/* ============================================================
   main.c  —  Entry point: hardware init + main FSM loop
   ============================================================
   Target  : ATmega328P  (Arduino Uno / Nano compatible)
   Toolchain: avr-gcc  (avr-libc)
   Build   : see Makefile
   ============================================================ */

#include <avr/io.h>
#include <avr/interrupt.h>

#include "config.h"
#include "game.h"
#include "timer.h"
#include "adc.h"
#include "random.h"
#include "lcd.h"
#include "tone.h"
#include "input.h"
#include "display.h"
#include "audio.h"
#include "storage.h"
#include "menu.h"
#include "game_logic.h"
#include "score.h"

/* ── Global state ────────────────────────────────────────── */
GameState g;
bool_t    menuDrawn = FALSE;

/* ── GPIO initialisation ─────────────────────────────────── */
static void gpio_init(void)
{
    /*
     * LEDs  — outputs, initially LOW
     * PD6, PD7 (LED 1, 2)
     */
    LED_DDR  |= (1u << LED_1_BIT) | (1u << LED_2_BIT);
    LED_PORT &= ~((1u << LED_1_BIT) | (1u << LED_2_BIT));

    /* PB0, PB1 (LED 3, 4) */
    LED_34_DDR  |= (1u << LED_3_BIT) | (1u << LED_4_BIT);
    LED_34_PORT &= ~((1u << LED_3_BIT) | (1u << LED_4_BIT));

    /*
     * P1 buttons  PD2–PD5 — inputs with pull-up
     * DDR bit = 0 (input), PORT bit = 1 (pull-up enable)
     */
    P1_DDR  &= ~((1u<<P1_BTN1_BIT)|(1u<<P1_BTN2_BIT)|
                 (1u<<P1_BTN3_BIT)|(1u<<P1_BTN4_BIT));
    P1_PORT |=  ((1u<<P1_BTN1_BIT)|(1u<<P1_BTN2_BIT)|
                 (1u<<P1_BTN3_BIT)|(1u<<P1_BTN4_BIT));

    /*
     * P2 buttons  PC0–PC3 — inputs with pull-up
     */
    P2_DDR  &= ~((1u<<P2_BTN1_BIT)|(1u<<P2_BTN2_BIT)|
                 (1u<<P2_BTN3_BIT)|(1u<<P2_BTN4_BIT));
    P2_PORT |=  ((1u<<P2_BTN1_BIT)|(1u<<P2_BTN2_BIT)|
                 (1u<<P2_BTN3_BIT)|(1u<<P2_BTN4_BIT));

    /* Buzzer PB2 — output, initially LOW */
    BUZ_DDR  |= (1u << BUZ_BIT);
    BUZ_PORT &= ~(1u << BUZ_BIT);
}

/* ── Game state reset ────────────────────────────────────── */
void reset_game_state(void)
{
    g.state           = STATE_MENU;
    g.menuCursor      = MENU_SOLO;
    menuDrawn         = FALSE;

    g.p1.score        = 0;
    g.p1.inputDone    = FALSE;
    g.p1.inputLen     = 0;

    g.p2.score        = 0;
    g.p2.inputDone    = FALSE;
    g.p2.inputLen     = 0;

    g.activeSeq.length = 0;
    g.playerTurn       = 1;
    g.challPhase       = CHALL_INPUT_A;
    g.awaitingInput    = FALSE;
    g.roundInProgress  = FALSE;
    g.compareIndex     = 0;

    g.lastActivityMs  = millis();
    g.turnStartMs     = millis();
}

/* ── Entry point ─────────────────────────────────────────── */
int main(void)
{
    /* 1. Hardware init */
    gpio_init();

    /* 2. Timer0 for millis() — must come before lcd_init()
          which calls delay_ms()                              */
    timer0_init();
    sei();                       /* Enable global interrupts */

    /* 3. Tone driver (Timer1 / OC1B) */
    tone_init();

    /* 4. ADC for RNG seed */
    adc_init();
    rng_seed((uint32_t)adc_read(RNG_ADC_CH));

    /* 5. LCD */
    lcd_init();
    lcd_backlight(1u);

    /* 6. Load high scores from EEPROM */
    storage_init();

    /* 7. Game state → menu */
    reset_game_state();

    /* 8. Welcome splash */
    display_splash();

    /* ── Main loop ──────────────────────────────────────── */
    for (;;) {

        /* Debounced button scan */
        input_update();

        /* Dispatch to active state handler */
        switch (g.state) {
            case STATE_MENU:          menu_update();        break;
            case STATE_SOLO_SPRINT:   solo_update();        break;
            case STATE_SYNC_DUEL:     duel_update();        break;
            case STATE_CHALLENGER:    challenger_update();  break;
            case STATE_SCORE_DISPLAY: score_update();       break;
            case STATE_SLEEP:         sleep_update();       break;
            default: break;
        }

        /* Global idle → sleep watchdog */
        if (g.state != STATE_SLEEP) {
            if ((uint32_t)(millis() - g.lastActivityMs) > SLEEP_TIMEOUT_MS) {
                enter_sleep();
            }
        }
    }

    return 0;   /* Never reached */
}
