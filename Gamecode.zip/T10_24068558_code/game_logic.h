#ifndef GAME_LOGIC_H
#define GAME_LOGIC_H

/* ============================================================
   game_logic.h  —  Game mode update functions
   ============================================================ */

void solo_update(void);
void duel_update(void);
void challenger_update(void);

#endif /* GAME_LOGIC_H */
