#ifndef CONFIG_H
#define CONFIG_H

/* ============================================================
   config.h  —  Hardware pin map & tunable constants
   Target: ATmega328P  (Arduino Uno/Nano footprint)
   All pin references are AVR port/bit notation, NOT Arduino
   pin numbers.
   ============================================================ */

#include <stdint.h>

/* ── Clock ──────────────────────────────────────────────── */
#define F_CPU  16000000UL   /* 16 MHz crystal */

/* ── LCD I2C (PCF8574 backpack) ─────────────────────────── */
#define LCD_I2C_ADDR    0x27   /* Try 0x3F if blank */
#define LCD_COLS        16
#define LCD_ROWS        2

/* ── LEDs  PD6–PD9  (Arduino D6–D9) ────────────────────── */
/*   DDRD bits 6-9 = OUTPUT,  PORTD bits 6-9 drive them      */
#define LED_DDR     DDRD
#define LED_PORT    PORTD
#define LED_1_BIT   6
#define LED_2_BIT   7
/* LED 3 & 4 live on PB0 and PB1 (Arduino D8, D9) */
#define LED_34_DDR  DDRB
#define LED_34_PORT PORTB
#define LED_3_BIT   0
#define LED_4_BIT   1
#define NUM_LEDS    4

/* ── Player-1 buttons  PD2–PD5  (Arduino D2–D5) ─────────── */
/*   INPUT_PULLUP → DDR = 0, PORT = 1; read from PIN         */
#define P1_DDR      DDRD
#define P1_PORT     PORTD   /* write 1 to enable pull-up */
#define P1_PIN      PIND    /* read actual level         */
#define P1_BTN1_BIT 2
#define P1_BTN2_BIT 3
#define P1_BTN3_BIT 4
#define P1_BTN4_BIT 5

/* ── Player-2 buttons  PC0–PC3  (Arduino A0–A3) ─────────── */
#define P2_DDR      DDRC
#define P2_PORT     PORTC
#define P2_PIN      PINC
#define P2_BTN1_BIT 0
#define P2_BTN2_BIT 1
#define P2_BTN3_BIT 2
#define P2_BTN4_BIT 3

/* ── Buzzer  PB2  (Arduino D10) ─────────────────────────── */
#define BUZ_DDR     DDRB
#define BUZ_PORT    PORTB
#define BUZ_BIT     2

/* ── I2C / TWI pins are fixed on ATmega328P ─────────────── */
/*   SDA = PC4 (A4),  SCL = PC5 (A5) — driven by hardware TWI */

/* ── Tone frequencies (Hz) ───────────────────────────────── */
#define TONE_CORRECT     1000u
#define TONE_WRONG        300u
#define TONE_GAMEOVER     150u
#define TONE_SELECT       700u
#define TONE_DURATION_MS  200u

/* ── Gameplay timing (ms) ────────────────────────────────── */
#define LED_ON_BASE_MS      600u
#define LED_ON_MIN_MS       150u
#define LED_BETWEEN_MS      200u
#define DIFFICULTY_STEP      50u
#define PLAYER_TIMEOUT_MS  5000u
#define SLEEP_TIMEOUT_MS  120000UL

/* ── Debounce ─────────────────────────────────────────────── */
#define DEBOUNCE_MS   30u

/* ── EEPROM ──────────────────────────────────────────────── */
#define EEPROM_ADDR_P1_HIGH  0    /* 2 bytes (int16_t) */
#define EEPROM_ADDR_P2_HIGH  2    /* 2 bytes           */
#define EEPROM_MAGIC_ADDR    4    /* 1 byte            */
#define EEPROM_MAGIC_VAL  0xAB

/* ── Sequence ────────────────────────────────────────────── */
#define MAX_SEQ_LEN  20

/* ── ADC channel for RNG seed (PC5 / A5 — floating) ─────── */
#define RNG_ADC_CH   5

#endif /* CONFIG_H */
