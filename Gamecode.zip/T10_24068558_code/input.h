#ifndef INPUT_H
#define INPUT_H

/* ============================================================
   input.h  —  Non-blocking software-debounced button input
   ============================================================ */

#include <stdint.h>
#include "game.h"

/* Call every main-loop iteration */
void input_update(void);

/* Return 1-4 if that player just pressed a button, else 0 */
int8_t p1_pressed(void);
int8_t p2_pressed(void);

/* True if either player pressed something this iteration */
bool_t any_pressed(void);

/* True if all 4 buttons for that player are physically held */
bool_t p1_all_held(void);
bool_t p2_all_held(void);

#endif /* INPUT_H */
