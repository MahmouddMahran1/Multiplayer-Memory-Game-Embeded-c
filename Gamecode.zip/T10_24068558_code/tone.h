#ifndef TONE_H
#define TONE_H

/* ============================================================
   tone.h  —  Passive buzzer tone generation via Timer1
   ============================================================
   Replaces Arduino tone() / noTone() with direct Timer1
   CTC-toggle on OC1A (PB1, Arduino D9).

   NOTE: The buzzer is wired to PB2 (Arduino D10) in this
   project, which is OC1B.  We use OC1B (COM1B0 toggle) so
   the hardware pin matches the original schematic.
   ============================================================ */

#include <stdint.h>

/* Output Compare B toggle mode on OC1B (PB2 / D10) */
void tone_init(void);
void tone_play(uint16_t freq_hz, uint16_t duration_ms);
void tone_stop(void);

#endif /* TONE_H */
