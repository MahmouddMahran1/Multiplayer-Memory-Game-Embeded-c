/* ============================================================
   input.c  —  Non-blocking debounced button reading
   ============================================================
   Buttons are active-LOW (INPUT_PULLUP wiring).
   GPIO is read directly via PINx registers.

   P1 buttons: PIND bits 2-5
   P2 buttons: PINC bits 0-3
   ============================================================ */

#include <avr/io.h>
#include "input.h"
#include "timer.h"
#include "config.h"

/* Bit positions for each button (index 0-3 = button 1-4) */
static const uint8_t P1_BITS_LOCAL[NUM_LEDS] = {
    P1_BTN1_BIT, P1_BTN2_BIT, P1_BTN3_BIT, P1_BTN4_BIT
};
static const uint8_t P2_BITS_LOCAL[NUM_LEDS] = {
    P2_BTN1_BIT, P2_BTN2_BIT, P2_BTN3_BIT, P2_BTN4_BIT
};

static uint32_t p1_last_ms[NUM_LEDS];
static uint32_t p2_last_ms[NUM_LEDS];
static bool_t   p1_state[NUM_LEDS];
static bool_t   p2_state[NUM_LEDS];
static bool_t   p1_event[NUM_LEDS];
static bool_t   p2_event[NUM_LEDS];

/* ── GPIO helpers ────────────────────────────────────────── */
static inline bool_t p1_raw(uint8_t i)
{
    /* LOW when pressed (INPUT_PULLUP) */
    return (bool_t)(!(P1_PIN & (1u << P1_BITS_LOCAL[i])));
}
static inline bool_t p2_raw(uint8_t i)
{
    return (bool_t)(!(P2_PIN & (1u << P2_BITS_LOCAL[i])));
}

/* ── Public API ──────────────────────────────────────────── */

void input_update(void)
{
    uint32_t now = millis();

    for (uint8_t i = 0u; i < NUM_LEDS; i++) {
        p1_event[i] = FALSE;
        p2_event[i] = FALSE;

        /* ── Player 1 ─────────────────────────────────────── */
        bool_t raw1 = p1_raw(i);
        if (raw1 != p1_state[i]) {
            if ((uint32_t)(now - p1_last_ms[i]) >= DEBOUNCE_MS) {
                p1_state[i]   = raw1;
                p1_last_ms[i] = now;
                if (raw1) {
                    p1_event[i]      = TRUE;
                    g.lastActivityMs = now;
                }
            }
        } else {
            p1_last_ms[i] = now;   /* Keep resetting while stable */
        }

        /* ── Player 2 ─────────────────────────────────────── */
        bool_t raw2 = p2_raw(i);
        if (raw2 != p2_state[i]) {
            if ((uint32_t)(now - p2_last_ms[i]) >= DEBOUNCE_MS) {
                p2_state[i]   = raw2;
                p2_last_ms[i] = now;
                if (raw2) {
                    p2_event[i]      = TRUE;
                    g.lastActivityMs = now;
                }
            }
        } else {
            p2_last_ms[i] = now;
        }
    }
}

int8_t p1_pressed(void)
{
    for (uint8_t i = 0u; i < NUM_LEDS; i++) {
        if (p1_event[i]) return (int8_t)(i + 1u);
    }
    return 0;
}

int8_t p2_pressed(void)
{
    for (uint8_t i = 0u; i < NUM_LEDS; i++) {
        if (p2_event[i]) return (int8_t)(i + 1u);
    }
    return 0;
}

bool_t any_pressed(void)
{
    return (bool_t)(p1_pressed() != 0 || p2_pressed() != 0);
}

bool_t p1_all_held(void)
{
    for (uint8_t i = 0u; i < NUM_LEDS; i++) {
        if (!p1_raw(i)) return FALSE;
    }
    return TRUE;
}

bool_t p2_all_held(void)
{
    for (uint8_t i = 0u; i < NUM_LEDS; i++) {
        if (!p2_raw(i)) return FALSE;
    }
    return TRUE;
}
