/* ============================================================
   lcd.c  —  HD44780 via PCF8574 I2C backpack
   ============================================================
   PCF8574 bit map  (standard backpack wiring):
     bit 7 = DB7    bit 4 = DB4
     bit 3 = BL     bit 2 = EN    bit 1 = RW    bit 0 = RS
   We always write 4-bit mode (high nibble then low nibble).
   ============================================================ */

#include <util/delay.h>
#include "lcd.h"
#include "i2c.h"
#include "config.h"

/* PCF8574 bit positions */
#define LCD_RS   0x01u
#define LCD_RW   0x02u
#define LCD_EN   0x04u
#define LCD_BL   0x08u   /* Backlight control */

static uint8_t _bl = LCD_BL;   /* Backlight state */

/* ── Low-level: send one byte over I2C to the expander ───── */
static void pcf_write(uint8_t data)
{
    uint8_t buf = data | _bl;
    i2c_write_bytes(LCD_I2C_ADDR, &buf, 1u);
}

/* ── Pulse EN high-low to latch the 4-bit nibble ─────────── */
static void lcd_pulse_en(uint8_t data)
{
    pcf_write(data | LCD_EN);
    _delay_us(1);
    pcf_write(data & ~LCD_EN);
    _delay_us(50);
}

/* ── Send 4-bit nibble (RS selects data vs command) ─────── */
static void lcd_write4(uint8_t nibble, uint8_t rs)
{
    /* nibble occupies bits 7:4 of the PCF byte */
    uint8_t data = (nibble & 0xF0u) | rs;
    lcd_pulse_en(data);
}

/* ── Send full 8-bit value as two nibbles ────────────────── */
static void lcd_send(uint8_t val, uint8_t rs)
{
    lcd_write4(val & 0xF0u, rs);          /* high nibble */
    lcd_write4((uint8_t)(val << 4u), rs); /* low  nibble */
}

#define lcd_cmd(c)   lcd_send((c), 0u)
#define lcd_data(d)  lcd_send((d), LCD_RS)

/* ── Public API ──────────────────────────────────────────── */

void lcd_init(void)
{
    i2c_init();
    _delay_ms(50);

    /* Initialise in 4-bit mode per HD44780 datasheet sequence */
    lcd_write4(0x30u, 0u); _delay_ms(5);
    lcd_write4(0x30u, 0u); _delay_us(100);
    lcd_write4(0x30u, 0u); _delay_us(100);
    lcd_write4(0x20u, 0u); _delay_us(100);  /* Switch to 4-bit */

    lcd_cmd(0x28u);   /* 4-bit, 2 lines, 5x8 font */
    lcd_cmd(0x0Cu);   /* Display ON, cursor OFF, blink OFF */
    lcd_cmd(0x06u);   /* Entry mode: increment, no shift */
    lcd_cmd(0x01u);   /* Clear display */
    _delay_ms(2);
}

void lcd_backlight(uint8_t on)
{
    _bl = on ? LCD_BL : 0u;
    pcf_write(0u);    /* Send a dummy byte to apply backlight bit */
}

void lcd_clear(void)
{
    lcd_cmd(0x01u);
    _delay_ms(2);
}

void lcd_set_cursor(uint8_t col, uint8_t row)
{
    static const uint8_t row_offsets[] = { 0x00u, 0x40u };
    if (row >= LCD_ROWS) row = 0u;
    if (col >= LCD_COLS) col = 0u;
    lcd_cmd((uint8_t)(0x80u | (col + row_offsets[row])));
}

void lcd_print_char(char c)
{
    lcd_data((uint8_t)c);
}

void lcd_print_str(const char *s)
{
    while (*s) lcd_data((uint8_t)*s++);
}

void lcd_print_int(int16_t n)
{
    char buf[7];
    int8_t i = 0;
    uint8_t neg = 0u;

    if (n < 0) { neg = 1u; n = (int16_t)-n; }
    if (n == 0) { lcd_data('0'); return; }

    while (n > 0) {
        buf[i++] = (char)('0' + (n % 10));
        n /= 10;
    }
    if (neg) buf[i++] = '-';

    /* Reverse */
    for (int8_t j = i - 1; j >= 0; j--) lcd_data((uint8_t)buf[j]);
}
