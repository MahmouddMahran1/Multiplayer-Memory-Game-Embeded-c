/* ============================================================
   random.c  —  Linear Congruential Generator (LCG)
   ============================================================
   Parameters from Numerical Recipes:
     X(n+1) = 1664525 * X(n) + 1013904223  (mod 2^32)
   ============================================================ */

#include "random.h"

static uint32_t _seed = 1u;

void rng_seed(uint32_t seed)
{
    _seed = seed ? seed : 1u;   /* Never seed with 0 */
}

static uint32_t rng_raw(void)
{
    _seed = 1664525UL * _seed + 1013904223UL;
    return _seed;
}

int32_t rng_next(int32_t lo, int32_t hi)
{
    if (hi <= lo) return lo;
    uint32_t range = (uint32_t)(hi - lo);
    return lo + (int32_t)(rng_raw() % range);
}
