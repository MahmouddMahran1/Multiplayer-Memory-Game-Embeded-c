/* ============================================================
   display.c  —  LCD (via lcd.h) + LED output
   ============================================================
   LEDs are driven directly via PORTD/PORTB registers.
   LED 1 = PD6, LED 2 = PD7, LED 3 = PB0, LED 4 = PB1
   ============================================================ */

#include <avr/io.h>
#include <string.h>
#include "display.h"
#include "lcd.h"
#include "timer.h"
#include "game.h"
#include "config.h"

/* ── LED bit positions (parallel to LED index 0-3) ─────── */
/* LEDs 1-2 are on PORTD; LEDs 3-4 are on PORTB            */
static void led_set_raw(uint8_t idx, uint8_t on)
{
    switch (idx) {
        case 0: if(on) PORTD |= (1u<<LED_1_BIT); else PORTD &= ~(1u<<LED_1_BIT); break;
        case 1: if(on) PORTD |= (1u<<LED_2_BIT); else PORTD &= ~(1u<<LED_2_BIT); break;
        case 2: if(on) LED_34_PORT |= (1u<<LED_3_BIT); else LED_34_PORT &= ~(1u<<LED_3_BIT); break;
        case 3: if(on) LED_34_PORT |= (1u<<LED_4_BIT); else LED_34_PORT &= ~(1u<<LED_4_BIT); break;
        default: break;
    }
}

/* ── Overwrite trailing spaces on row to clear stale chars ─ */
static void lcd_pad_row(uint8_t col, uint8_t row __attribute__((unused)), uint8_t used)
{
    uint8_t pad = col + used;
    while (pad < LCD_COLS) { lcd_print_char(' '); pad++; }
}

/* ── Public LED helpers ──────────────────────────────────── */

void led_on(int8_t num)
{
    if (num >= 1 && num <= NUM_LEDS) led_set_raw((uint8_t)(num - 1), 1u);
}

void led_off(int8_t num)
{
    if (num >= 1 && num <= NUM_LEDS) led_set_raw((uint8_t)(num - 1), 0u);
}

void leds_off(void)
{
    for (uint8_t i = 0u; i < NUM_LEDS; i++) led_set_raw(i, 0u);
}

/* ── Sequence flash ──────────────────────────────────────── */

void flash_sequence(const int16_t seq[], int16_t len, uint16_t on_ms)
{
    leds_off();
    delay_ms(400u);
    for (int16_t i = 0; i < len; i++) {
        uint8_t idx = (uint8_t)(seq[i] - 1);    /* 1-based → 0-based */
        led_set_raw(idx, 1u);
        delay_ms(on_ms);
        led_set_raw(idx, 0u);
        delay_ms(LED_BETWEEN_MS);
    }
}

/* ── LCD display helpers ─────────────────────────────────── */

void display_splash(void)
{
    lcd_clear();
    lcd_set_cursor(3u, 0u); lcd_print_str("Memory Game");
    lcd_set_cursor(4u, 1u); lcd_print_str("v1.0  :)");
    delay_ms(1500u);
    lcd_clear();
}

void display_menu(int8_t cursor)
{
    static const char *labels[] = { "Solo Sprint", "Sync Duel ", "Challenger" };
    int8_t next = (int8_t)((cursor + 1) % MENU_COUNT);
    lcd_clear();
    lcd_set_cursor(0u, 0u);
    lcd_print_char('>');
    lcd_print_str(labels[cursor]);
    lcd_set_cursor(0u, 1u);
    lcd_print_char(' ');
    lcd_print_str(labels[next]);
}

void display_scores(void)
{
    lcd_set_cursor(0u, 1u);
    lcd_print_str("P1:");
    lcd_print_int(g.p1.score);
    lcd_print_str("  P2:");
    lcd_print_int(g.p2.score);
    /* Pad remaining columns to overwrite stale characters */
    lcd_pad_row(0u, 1u, 14u);
}

void display_msg(const char *line0)
{
    lcd_set_cursor(0u, 0u);
    lcd_print_str(line0);
    uint8_t used = (uint8_t)strlen(line0);
    lcd_pad_row(0u, 0u, used);
    display_scores();
}

void display_full(const char *line0, const char *line1)
{
    lcd_clear();
    lcd_set_cursor(0u, 0u); lcd_print_str(line0);
    lcd_set_cursor(0u, 1u); lcd_print_str(line1);
}

void display_win(void)
{
    for (uint8_t t = 0u; t < 3u; t++) {
        for (uint8_t i = 0u; i < NUM_LEDS; i++) led_set_raw(i, 1u);
        delay_ms(200u);
        leds_off();
        delay_ms(150u);
    }
}

void display_sleep(void)
{
    leds_off();
    lcd_clear();
    lcd_backlight(0u);
}

void display_wake(void)
{
    lcd_backlight(1u);
    display_full(" Press any btn ", "   to start..  ");
}

void display_final_score(void)
{
    lcd_clear();
    lcd_set_cursor(0u, 0u);
    lcd_print_str("P1:");
    lcd_print_int(g.p1.score);
    lcd_print_str(" P2:");
    lcd_print_int(g.p2.score);
    lcd_set_cursor(0u, 1u);
    if      (g.p1.score > g.p2.score) lcd_print_str("  P1 WINS!    ");
    else if (g.p2.score > g.p1.score) lcd_print_str("  P2 WINS!    ");
    else                               lcd_print_str("  TIE GAME!   ");
}
