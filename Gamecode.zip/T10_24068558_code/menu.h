#ifndef MENU_H
#define MENU_H

/* ============================================================
   menu.h  —  Menu state handler
   ============================================================ */

#include "game.h"

void menu_update(void);
void start_mode(MenuOption mode);

#endif /* MENU_H */
