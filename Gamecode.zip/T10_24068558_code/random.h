#ifndef RANDOM_H
#define RANDOM_H

/* ============================================================
   random.h  —  LCG pseudo-random number generator
   Replaces Arduino's random() / randomSeed()
   ============================================================ */

#include <stdint.h>

void    rng_seed(uint32_t seed);
int32_t rng_next(int32_t lo, int32_t hi);  /* Returns value in [lo, hi) */

#endif /* RANDOM_H */
