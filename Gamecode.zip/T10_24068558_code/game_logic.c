/* ============================================================
   game_logic.c  —  Solo Sprint, Sync Duel, The Challenger
   ============================================================ */

#include "game_logic.h"
#include "game.h"
#include "display.h"
#include "audio.h"
#include "input.h"
#include "storage.h"
#include "timer.h"
#include "random.h"
#include "config.h"

/* ── Shared helpers ──────────────────────────────────────── */

static uint16_t led_on_ms(int16_t score)
{
    int16_t ms = (int16_t)LED_ON_BASE_MS - (score * (int16_t)DIFFICULTY_STEP);
    if (ms < (int16_t)LED_ON_MIN_MS) ms = (int16_t)LED_ON_MIN_MS;
    return (uint16_t)ms;
}

static void grow_sequence(void)
{
    if (g.activeSeq.length < MAX_SEQ_LEN) {
        g.activeSeq.data[g.activeSeq.length] =
            (int16_t)rng_next(1, (int32_t)(NUM_LEDS + 1));
        g.activeSeq.length++;
    }
}

static void clear_input_buffers(void)
{
    g.p1.inputLen   = 0;
    g.p1.inputDone  = FALSE;
    g.p2.inputLen   = 0;
    g.p2.inputDone  = FALSE;
    g.compareIndex  = 0;
    g.awaitingInput = FALSE;
}

/*
 * Returns:
 *   0  — wrong button pressed
 *   1  — sequence complete and correct
 *  -1  — still going (correct so far, not finished)
 */
static int8_t check_input(int16_t *input_seq, int16_t input_len)
{
    if (input_len == 0) return -1;
    int16_t last = input_len - 1;
    if (input_seq[last] != g.activeSeq.data[last]) return 0;
    if (input_len == g.activeSeq.length)            return 1;
    return -1;
}

/* ── SOLO SPRINT ─────────────────────────────────────────── */

void solo_update(void)
{
    if (!g.roundInProgress) {
        grow_sequence();
        clear_input_buffers();
        display_msg("Watch the LEDs!");
        delay_ms(600u);

        flash_sequence(g.activeSeq.data,
                       g.activeSeq.length,
                       led_on_ms(g.p1.score));

        display_msg("Your turn P1!");
        g.awaitingInput    = TRUE;
        g.roundInProgress  = TRUE;
        g.turnStartMs      = millis();
        display_scores();
        return;
    }

    if (g.awaitingInput) {

        /* Timeout check */
        if ((uint32_t)(millis() - g.turnStartMs) > PLAYER_TIMEOUT_MS) {
            display_full("  Time's up!  ", "  Game Over!  ");
            audio_game_over();
            storage_update_high();
            delay_ms(2000u);
            g.state = STATE_SCORE_DISPLAY;
            return;
        }

        int8_t btn = p1_pressed();
        if (btn != 0) {
            led_on(btn);
            audio_select();
            g.p1.inputSeq[g.p1.inputLen++] = btn;
            g.turnStartMs = millis();

            int8_t result = check_input(g.p1.inputSeq, g.p1.inputLen);

            if (result == 0) {
                led_off(btn);
                audio_wrong();
                display_full("  WRONG!  ", "  Game Over!  ");
                audio_game_over();
                storage_update_high();
                delay_ms(2000u);
                g.state = STATE_SCORE_DISPLAY;
                return;
            } else if (result == 1) {
                led_off(btn);
                audio_correct();
                display_win();
                g.p1.score++;
                display_msg("Correct! +1 pt");
                display_scores();
                audio_win();
                delay_ms(1000u);
                g.roundInProgress = FALSE;
            } else {
                delay_ms(80u);
                led_off(btn);
            }
        }
    }
}

/* ── SYNCHRONOUS DUEL ────────────────────────────────────── */

void duel_update(void)
{
    if (!g.roundInProgress) {
        grow_sequence();
        clear_input_buffers();
        display_full("Both watch!", "Sequence:");
        delay_ms(600u);

        flash_sequence(g.activeSeq.data,
                       g.activeSeq.length,
                       led_on_ms((int16_t)(g.p1.score + g.p2.score)));

        display_msg("GO! Both enter!");
        g.awaitingInput    = TRUE;
        g.roundInProgress  = TRUE;
        g.turnStartMs      = millis();
        display_scores();
        return;
    }

    if (g.awaitingInput) {

        if ((uint32_t)(millis() - g.turnStartMs) > PLAYER_TIMEOUT_MS) {
            display_full("Timeout!", "No points.");
            audio_wrong();
            delay_ms(1500u);
            g.roundInProgress  = FALSE;
            g.activeSeq.length = 0;
            return;
        }

        if (!g.p1.inputDone) {
            int8_t b1 = p1_pressed();
            if (b1) {
                led_on(b1);
                audio_select();
                g.p1.inputSeq[g.p1.inputLen++] = b1;
                delay_ms(60u);
                led_off(b1);
                int8_t r = check_input(g.p1.inputSeq, g.p1.inputLen);
                if (r == 0) { g.p1.inputDone = TRUE; g.p1.inputLen = -1; }
                if (r == 1) { g.p1.inputDone = TRUE; }
            }
        }

        if (!g.p2.inputDone) {
            int8_t b2 = p2_pressed();
            if (b2) {
                led_on(b2);
                audio_select();
                g.p2.inputSeq[g.p2.inputLen++] = b2;
                delay_ms(60u);
                led_off(b2);
                int8_t r = check_input(g.p2.inputSeq, g.p2.inputLen);
                if (r == 0) { g.p2.inputDone = TRUE; g.p2.inputLen = -1; }
                if (r == 1) { g.p2.inputDone = TRUE; }
            }
        }

        if (g.p1.inputDone && g.p2.inputDone) {
            bool_t p1ok = (bool_t)(g.p1.inputLen != -1);
            bool_t p2ok = (bool_t)(g.p2.inputLen != -1);

            if (p1ok && p2ok) {
                g.p1.score++; g.p2.score++;
                display_full("Both correct!", "+1 each");
                audio_win();
            } else if (p1ok) {
                g.p1.score++;
                display_full("P1 correct!", "P1 +1 pt");
                audio_correct();
            } else if (p2ok) {
                g.p2.score++;
                display_full("P2 correct!", "P2 +1 pt");
                audio_correct();
            } else {
                display_full("Both wrong!", "No points.");
                audio_wrong();
            }
            display_scores();
            delay_ms(1800u);
            g.roundInProgress  = FALSE;
            g.activeSeq.length = 0;
        }
    }
}

/* ── THE CHALLENGER ──────────────────────────────────────── */

void challenger_update(void)
{
    switch (g.challPhase) {

    /* ── Phase 1: P1 enters secret sequence ───────────────── */
    case CHALL_INPUT_A:
    {
        static bool_t instructed = FALSE;
        if (!instructed) {
            display_full("P1: enter seq.", "BTN 4 = done");
            g.p1.inputLen = 0;
            g.turnStartMs = millis();
            instructed    = TRUE;
        }

        if ((uint32_t)(millis() - g.turnStartMs) > PLAYER_TIMEOUT_MS * 2u) {
            display_full("P1 timed out.", "Restarting...");
            delay_ms(1500u);
            instructed  = FALSE;
            menuDrawn   = FALSE;
            g.state     = STATE_MENU;
            return;
        }

        int8_t btn        = p1_pressed();
        bool_t doTransit  = FALSE;

        if (btn >= 1 && btn <= 3) {
            g.p1.inputSeq[g.p1.inputLen++] = btn;
            led_on(btn); delay_ms(120u); led_off(btn);
            audio_select();
            g.turnStartMs = millis();
            if (g.p1.inputLen >= MAX_SEQ_LEN) doTransit = TRUE;
        }

        if ((btn == 4 && g.p1.inputLen > 0) || doTransit) {
            g.activeSeq.length = g.p1.inputLen;
            for (int16_t i = 0; i < g.p1.inputLen; i++) {
                g.activeSeq.data[i] = g.p1.inputSeq[i];
            }
            instructed   = FALSE;
            g.challPhase = CHALL_REPLICATE_B;
            display_full("P2: replicate!", "Watch:");
            delay_ms(800u);
            flash_sequence(g.activeSeq.data, g.activeSeq.length, led_on_ms(0));
            display_full("P2: go!", "");
            g.p2.inputLen = 0;
            g.turnStartMs = millis();
        }
        break;
    }

    /* ── Phase 2: P2 tries to replicate ─────────────────── */
    case CHALL_REPLICATE_B:
    {
        if ((uint32_t)(millis() - g.turnStartMs) > PLAYER_TIMEOUT_MS) {
            display_full("P2 timed out!", "P1 must prove!");
            audio_wrong();
            delay_ms(1200u);
            g.challPhase  = CHALL_PROOF_A;
            g.p1.inputLen = 0;
            g.turnStartMs = millis();
            return;
        }

        int8_t btn = p2_pressed();
        if (btn) {
            led_on(btn);
            audio_select();
            g.p2.inputSeq[g.p2.inputLen++] = btn;
            delay_ms(80u);
            led_off(btn);
            g.turnStartMs = millis();

            int8_t r = check_input(g.p2.inputSeq, g.p2.inputLen);
            if (r == 0) {
                display_full("P2 wrong!", "P1 must prove!");
                audio_wrong();
                delay_ms(1200u);
                g.challPhase  = CHALL_PROOF_A;
                g.p1.inputLen = 0;
                g.turnStartMs = millis();
            } else if (r == 1) {
                g.p2.score++;
                display_full("P2 correct!", "P2 gets point!");
                audio_win();
                display_scores();
                delay_ms(1800u);
                g.challPhase = CHALL_RESULT;
            }
        }
        break;
    }

    /* ── Phase 3: P1 must prove the sequence is valid ────── */
    case CHALL_PROOF_A:
    {
        static bool_t proof_instructed = FALSE;
        if (!proof_instructed) {
            display_full("P1: prove it!", "Re-enter seq.");
            proof_instructed = TRUE;
        }

        if ((uint32_t)(millis() - g.turnStartMs) > PLAYER_TIMEOUT_MS) {
            display_full("P1 timed out!", "No points.");
            audio_wrong();
            delay_ms(1500u);
            proof_instructed = FALSE;
            g.challPhase     = CHALL_RESULT;
            return;
        }

        int8_t btn = p1_pressed();
        if (btn) {
            led_on(btn);
            audio_select();
            g.p1.inputSeq[g.p1.inputLen++] = btn;
            delay_ms(80u);
            led_off(btn);
            g.turnStartMs = millis();

            int8_t r = check_input(g.p1.inputSeq, g.p1.inputLen);
            if (r == 0) {
                display_full("P1 failed!", "No points.");
                audio_game_over();
                delay_ms(1500u);
                proof_instructed = FALSE;
                g.challPhase     = CHALL_RESULT;
            } else if (r == 1) {
                g.p1.score++;
                display_full("P1 proved it!", "P1 gets point!");
                audio_win();
                display_scores();
                delay_ms(1800u);
                proof_instructed = FALSE;
                g.challPhase     = CHALL_RESULT;
            }
        }
        break;
    }

    /* ── Phase 4: Show round result, wait for next action ── */
    case CHALL_RESULT:
    {
        static bool_t result_shown = FALSE;
        if (!result_shown) {
            display_full("Round done!", "P4=menu P3=next");
            result_shown = TRUE;
        }

        int8_t b1 = p1_pressed();
        if (b1 == 3) {
            result_shown = FALSE;
            g.challPhase = CHALL_INPUT_A;
            display_full("Next round!", "P1: enter seq.");
            delay_ms(800u);
        } else if (b1 == 4) {
            result_shown = FALSE;
            storage_update_high();
            g.state = STATE_SCORE_DISPLAY;
        }
        break;
    }

    default: break;
    }
}
